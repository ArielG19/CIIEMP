<!-- Modal -->
      <div class="modal fade" id="myModal" tabindex="-1" role="dialog" 
          aria-labelledby="myModalLabel" ria-hidden="true">
          <div class="modal-dialog">
              <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                          <h4 class="modal-title" id="myModalLabel">Acerca de:<b id="acerca"></b> </h4>
                      </div>
                      <div class="modal-body">
                            <center>
                          <a>
                            <img id="im" src="/perfil/default.jpg" name="aboutme" width="140" height="140" border="0" class="img-circle" >
                          </a>
                            <br>
                            <hr>
                            <span><h4>Profesiones: </h4></span><br>
                              <span id="label1" class="label label-success"></span>
                              <span id="label2" class="label label-info"></span>
                              <span id="label3" class="label label-primary"></span>

                              <span id="label4" class="label label-warning"></span>
                            </center>
                            <hr>
                        </div>
                      <div class="modal-footer">
                          <center>
                          <a id="public" class="btn btn-default" href="">publicaciones</a>
                          <a id="blog" class="btn btn-default" href="">Blog</a>
                          <a id="curr" class="btn btn-default" href="">curriculon viate</a>
                          </center>
                      </div>
              </div>
          </div>
      </div>
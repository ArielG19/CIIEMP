<footer class="row">

    <div class="fh5co-footer-style-3">

		<div class="col-md-3 col-sm-6 fh5co-footer-widget wow fadeInUp" data-wow-duration="1s" data-wow-delay=".5s">
				<div class="fh5co-logo"><span class="logo">C</span>IIEMP</div>
				<p class="fh5co-copyright">&copy; 2017.
					<br>
						Derechos Reservados
					<br>
						Página Web diseñada por :
					<a target="_blank" href="#"></a>
					<br>

					<a target="_blank" href="#">Greyner Cáceres</a>
					<br>

					<a target="_blank" href="https://arielg19.github.io/mySite/">Rubén Perez</a>
					<br>

					<a target="_blank" href="https://holamusicos.wordpress.com/">David Rivera Lanuza</a>
					<br>

				</p>
		</div>

		<div class="col-md-3 col-sm-6 fh5co-footer-widget wow fadeInUp" data-wow-duration="1s" data-wow-delay=".8s">

			<ul class="fh5co-links">
			<h3>CIIEMP</h3>
				<li><a href="#">Bolsa Empleo</a></li>
				<li><a href="#">Obserbatorio Socioeconómico</a></li>
        <li><a href="{{ url('/docentes-innovadores') }}">Docentes Investigadores</a></li>
				<li><a href="{{ url('bloghome') }}">Blog</a></li>
        <li><a href="{{ url('biblioteca') }}">Repositorio</a></li>
        <li><a href="{{ url('articulohome') }}">Noticias</a></li>
        <li><a href="{{ url('proyectos')}}">Proyectos</a></li>

			</ul>
		</div>
		<div class="clearfix visible-sm-block"></div>
		<div class="col-md-3 col-sm-6 fh5co-footer-widget wow fadeInUp" data-wow-duration="1s" data-wow-delay="1.1s">
			<h3>Síguenos</h3>
			<ul class="fh5co-links fh5co-social">
				<li><a href="https://www.facebook.com/CiiempFaremEsteli/"><i class="icon icon-facebook2"></i> Facebook</a></li>
				<li><a href="#"><i class="icon icon-twitter"></i> Twitter</a></li>
				<li><a href="#"><i class="icon icon-instagram"></i> Instagram</a></li>
			</ul>
		</div>

		<div class="col-md-3 col-sm-6 fh5co-footer-widget wow fadeInUp" data-wow-duration="1s" data-wow-delay="1.4s">
			<h3>Acerca de nosotros</h3>
			<p>Somos una instancia de la UNAN-Managua-FAREM-Estelí dedicada a la investigación aplicada para la promoción y desarrollo de proyectos de innovación y emprendimiento. </p>
			<p><a href="{{ url('/acercade') }}" class="btn btn-success btn-sm btn-outline">Más...</a></p>
		</div>

		<div class="clearfix visible-sm-block"></div>

		<div class="container fh5co-made">

		</div>

	</div>

	<div class="fh5co-footer-style-3 fondo color">

		<div class="col-md-3 col-sm-6 fh5co-footer-widget wow fadeInUp estilo"><img src="{{asset('styleVoltage/images/Marca Negativo.png')}}" alt="" width="60%"></div>

		<div class="col-md-3 col-sm-6 fh5co-footer-widget wow fadeInUp estilo2"><img src="{{asset('styleVoltage/images/CIIEMP-Coloroscuro Negativo.png')}}" alt="" width="50%"></div>
	</div>
<!-- END footer -->


	<style>
	.fondo{

		height: 100px;
	}
		.estilo{
			margin-top: -4.5em;

		}
		.estilo2{
			margin-top: -4em;

		}

	.color{
		background:#0F0F0F;

	}
	</style>
</footer>
